import os
from dotenv import load_dotenv
from google import genai
import time

# Load API key
load_dotenv()
api_key = os.getenv("GEMINI_API_KEY")

if not api_key:
    raise ValueError("Gemini API key not found!")

# Initialize Gemini
client = genai.Client(api_key=api_key)

# Try sending the prompt
print("Connecting to Gemini AI...")

for attempt in range(3):
    try:
        response = client.models.generate_content(
            model="gemini-3.5-flash-lite",
            contents="What is Artificial Intelligence? Explain in simple words."
        )

        print("\n========== LLM RESPONSE ==========\n")
        print(response.text)
        print("\n=================================")
        break

    except Exception as e:
        print(f"Attempt {attempt + 1} failed: {e}")

        if attempt < 2:
            print("Retrying in 5 seconds...")
            time.sleep(5)
        else:
            print("Unable to get a response. Please try again later.")